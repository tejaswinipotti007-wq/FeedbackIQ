@echo off
echo Stopping Feedback Intelligence...
docker-compose down
echo Done. App stopped.
pause