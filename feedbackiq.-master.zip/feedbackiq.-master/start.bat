@echo off
echo ============================================
echo   Feedback Intelligence - Starting App
echo ============================================
echo.
echo Checking Docker...
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Docker is not installed or not running.
    echo Please install Docker Desktop from https://docker.com/products/docker-desktop
    echo Then start Docker Desktop and try again.
    pause
    exit /b
)

echo Docker found. Building and starting...
echo This may take 2-3 minutes the first time.
echo.
docker-compose up --build -d

echo.
echo ============================================
echo   App is running!
echo   Open your browser at: http://localhost:3000
echo ============================================
echo.
start http://localhost:3000
pause